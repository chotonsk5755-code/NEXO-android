NEXO Android starter project

This is an Android Studio project wrapper for the NEXO demo interface.
It is source code, NOT a compiled APK.

How to build:
1. Install Android Studio on a computer.
2. Open this extracted NEXO folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Current limitations:
- Demo-only local data; orders are not sent to a server.
- No real accounts, OTP, payment processing, GPS tracking or drone integration.
- Do not collect customer payment details until a secure backend and approved payment provider are implemented.

ANDROID-PHONE-ONLY BUILD OPTION (cloud build):
1. Open github.com in Chrome and sign in or create an account.
2. Create a new repository named NEXO-Android.
3. Upload the extracted project files and folders (including the hidden .github folder).
4. Open the repository's Actions tab.
5. Select "Build NEXO APK" and tap "Run workflow".
6. When it finishes, open the completed run and download the "NEXO-debug-APK" artifact.
7. Extract the downloaded artifact ZIP; it contains app-debug.apk.

This cloud build requires internet and a GitHub account. The APK is a debug/test build, not a Play Store release.
